from django.contrib import admin
from .models import TenderProposal, ProposalSection

admin.site.register(TenderProposal)
admin.site.register(ProposalSection)
